<?php


function redirect($url)
{
    header('Location: ' . $url);
    exit();
}






function emailValidate($email)
{
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function phoneValidate($phone)
{
    return preg_match('/^0\d{9}$/', $phone);
}

function redirectIfNotLoggedIn()
{
    global $userClass;

    if (!$userClass->isLoggedIn()) {
        redirect(site_url('login'));
    }
}

function bcrypt($password)
{
    return password_hash($password, PASSWORD_BCRYPT);
}



function now()
{
    return date('Y-m-d H:i:s');
}


function responseJson($data): void
{
    header('Content-Type: application/json');
    echo json_encode($data);
    exit();
}

function asset($path)
{
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $path = $protocol . $host . '/' . $path;

    return $path;
}





function str_random($length = 10)
{
    $characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $charactersLength = strlen($characters);
    $randomString = '';
    for ($i = 0; $i < $length; $i++) {
        $randomString .= $characters[rand(0, $charactersLength - 1)];
    }

    return $randomString;
}

function site_url($path = '')
{
    $protocol = isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https://' : 'http://';
    $host = $_SERVER['HTTP_HOST'];
    $path = $protocol . $host . '/' . $path;

    return $path;
}




function productImage($image)
{
    if($image == null) {
        return asset('public/images/no-image.png');
    }

    return asset('public/images/products/' . $image);
}