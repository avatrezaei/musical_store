<?php

// app name
define('APP_NAME', 'musical instrument retailer');

// app root
define('APP_ROOT', dirname(dirname(__FILE__)));
define('URL_ROOT', 'musical_store/');
define('ADMIN_URL', URL_ROOT . 'admin/');
define('URL_SUBFOLDER', '');
define('SITE_FOLDER','musical_store');

// database
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_DATABASE', 'musical_store');
define('DB_TIMEZONE', '+00:00');

define('DEBUG_MODE', 1);



?>