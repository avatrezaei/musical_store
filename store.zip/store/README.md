# php mvc musical shop
A musical instrument retailer would like to develop a new online shop to sale musical instruments and music sheets to their growing customer demands
